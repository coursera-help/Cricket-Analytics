setwd("C:\\F\\NMIMS\\DataScience\\Sem-2\\DS\\Clustering")

clusCatData<-read.csv("clustPrac.csv", header = TRUE, stringsAsFactors = FALSE)
head(clusCatData)
dim(clusCatData)

clusCatData1<-na.omit(clusCatData)
clusCatData<-scale(clusCatData[,2:10])
d <- dist(clusCatData, method = "euclidean")

######### Single ###################
singleFit<-hclust(d, method="single")
singleFit
singleFit$labels = clusCatData1$model
plot(singleFit)
data.frame(singleFit[2:1])
diff(data.frame(singleFit[2:1])$height)

######### Complete ###################
completeFit<-hclust(d, method="complete")
completeFit
completeFit$labels = clusCatData1$model
plot(completeFit)
data.frame(completeFit[2:1])
diff(data.frame(completeFit[2:1])$height)

######### Average ###################
avgFit<-hclust(d, method="average")
avgFit
avgFit$labels = clusCatData1$model
plot(avgFit)
data.frame(avgFit[2:1])
diff(data.frame(avgFit[2:1])$height)

###### Centroid ######
centroidFit<-hclust(d^2, method="centroid")
centroidFit
centroidFit$labels = clusCatData1$model
plot(centroidFit)
data.frame(centroidFit[2:1])

########### Ward #####################
wardFit<-hclust(d, method="ward.D2")
wardFit
wardFit$labels = clusCatData1$model
plot(wardFit)
data.frame(wardFit[2:1])




library(purrr)
library(cluster)

m <- c( "average", "single", "complete", "ward")
names(m) <- c( "average", "single", "complete", "ward")

# function to compute coefficient
ac <- function(x) {
  agnes(clusCatData, method = x)$ac
}

map_dbl(m, ac)
