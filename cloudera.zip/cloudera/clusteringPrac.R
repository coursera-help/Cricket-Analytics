data_kmeans<-matrix(c(2,2,8,5,7,6,1,4,10,5,4,8,5,4,2,9), nrow=8, ncol=2)
data_kmeans
model.kmean<-kmeans(data_kmeans, 3)
model.kmean


########### Hierarchical clustering ###########
setwd("C:\\F\\NMIMS\\DataScience\\Sem-2\\DS\\Clustering")
clusCatData<-read.csv("clustPrac.csv", header = TRUE, stringsAsFactors = FALSE)
head(clusCatData)
dim(clusCatData)
d<-dist(clusCatData[,2:10])

############ Single ########
singleFit<-hclust(d, method="single")
singleFit$height
diff(singleFit$height)
singleFit$labels=clusCatData$model
plot(singleFit)

############ Complete ########
completeFit<-hclust(d, method="complete")
completeFit$height
diff(completeFit$height)
completeFit$labels=clusCatData$model
plot(completeFit)

############ Average ########
averageFit<-hclust(d, method="average")
averageFit$height
diff(averageFit$height)
averageFit$labels=clusCatData$model
plot(averageFit)

############ Centroid ########
centroidFit<-hclust(d^2, method="centroid")
centroidFit$height
diff(centroidFit$height)
centroidFit$labels=clusCatData$model
plot(centroidFit)

############ Centroid ########
centroidFit<-hclust(d^2, method="centroid")
centroidFit$height
diff(centroidFit$height)
centroidFit$labels=clusCatData$model
plot(centroidFit)

############ median ########
medianFit<-hclust(d^2, method="median")
medianFit$height
diff(medianFit$height)
medianFit$labels=clusCatData$model
plot(medianFit)

############ median ########
wardFit<-hclust(d^2, method="ward.D")
wardFit$height
diff(wardFit$height)
wardFit$labels=clusCatData$model
plot(wardFit)


################### KNN ##################
library(class)
knnData<-read.csv("KNN.csv", header = TRUE, stringsAsFactors = FALSE)
train_knn<-knnData[1:24,1:2]
test_knn<-knnData[25,1:2]

knn.fit1<-knn(train_knn, test_knn, cl=knnData[1:24,]$Y, k=5)
knn.fit1



library(class)

kVsAccuracy = matrix(ncol = 2, nrow = 8)
i = 1
for (k in 3:10){
  predictions = knn(train = train_knn, test = test_knn,cl =  knnData[1:24,]$Y, k = k)
  kVsAccuracy[i,] = c(k,mean(predictions==knnData[1:24,]$Y))
  i = i+1
}
plot(kVsAccuracy[,1],kVsAccuracy[,2],type = "l",xlab = "Value of k", ylab = "Testing Accuracy",main = "Choosing value of k based on testing accuracy")



m<-matrix(c(0,1,4,5,1,0,2,6,4,2,0,3,5,6,3,0), nrow=4, ncol=4)
m<-as.dist(m, diag=TRUE)
sqm<-m^2
sqm<-as.dist(sqm, diag=TRUE)
